# UnityRestClient
A client library for making REST calls from Unity scripts

Compatible with iOS, Android, Windows Universal Apps, Windows Desktop and Mac desktop. Not verified on Linux, but should work no problem

The library is largely code file based with the exception of the JsonFx.dll plugin requirement for iOS. 

Samples on how to use it will come soon. 
