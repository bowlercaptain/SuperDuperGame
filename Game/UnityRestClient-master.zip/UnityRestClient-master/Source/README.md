# UnityRestClient
A client library for making REST calls from Unity scripts
